from django.apps import AppConfig


class PostsConfig(AppConfig):
    name = 'gallary'
    verbose_name ='Images'
